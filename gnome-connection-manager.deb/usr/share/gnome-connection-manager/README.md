gcm
===

Gnome Connection Manager

This is not my project. 

I got it from [here](http://kuthulu.com/gcm/). 

This is a github clone for safe keeping.

Thank you to the developer.
